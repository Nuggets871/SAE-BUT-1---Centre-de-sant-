/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sae.vue;
import java.awt.*;
import javax.swing.*;


/**
 *
 * @author chris
 */
public class MyFrame extends JFrame {
    MyFrame(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        this.setSize(500,500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);



    }
}
